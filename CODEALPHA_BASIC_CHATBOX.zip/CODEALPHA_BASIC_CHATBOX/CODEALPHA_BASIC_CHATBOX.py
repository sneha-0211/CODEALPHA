import tkinter as tk
from tkinter import scrolledtext

class Chatbox:
    def __init__(self, root):
        self.root = root
        self.root.title("Chatbox")
        self.root.geometry("400x500")
        self.root.configure(bg="#87CEEB") 

        
        self.chat_window = scrolledtext.ScrolledText(self.root, width=50, height=20, bg="#C9E4CA", fg="#000000")
        self.chat_window.pack(padx=10, pady=10)

    
        self.input_field = tk.Text(self.root, width=40, height=5, bg="#E5E5EA", fg="#333333")
        self.input_field.pack(padx=10, pady=10)

        
        self.send_button = tk.Button(self.root, text="Send", font=("Helvetica" , 12 , "bold") ,command=self.send_message, bg="#F7D2C4", fg="black")
        self.send_button.pack(padx=10, pady=10)

    def send_message(self):
        message = self.input_field.get("1.0", tk.END)
        self.chat_window.insert(tk.END, "User: " + message)
        self.input_field.delete("1.0", tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    chatbox = Chatbox(root)
    root.mainloop()