import tkinter as tk
from random import choice

class Hangman:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Hangman Game")
        self.list_of_words = ['RED', 'BLUE', 'GREEN', 'BLACK', 'WHITE']
        self.word = choice(self.list_of_words)
        self.guessed_letters = ['_'] * len(self.word)
        self.guessed_letters_count = 0
        self.incorrect_guesses = 0
        self.lives = 10
        self.create_widgets()

    def create_widgets(self):

        self.window.configure(bg="#9b59b6")

        self.header_label = tk.Label(self.window, text="Hangman Game", font=('Calibri', 36), bg="#3498db")
        self.header_label.pack(fill="x")

        self.instructions_label = tk.Label(self.window, text ='Instructions:\n 1. Guess a letter by typingit in the box in captial letters.\n 2. Click the "Guess" button to sumbit your guess.\n 3. If you guess a letter correctly, it will be revealed in the word\n 4. If you make a mistake, you will lose a try.\n 5. The game ends when you guess the word or run out the tries.', font='Calibri', bg="yellow", justify=tk.LEFT )
        self.instructions_label.pack(fill='x')
       
        self.word_label = tk.Label(self.window, text=' '.join(self.guessed_letters), font=('Calibri', 24), bg = "#e74c3c")
        self.word_label.pack(fill='x')

        self.guess_entry = tk.Entry(self.window, font=('Calibri', 24), bg = "GREY")
        self.guess_entry.pack(fill='x')

        self.guess_button = tk.Button(self.window, text='Guess', command=self.check_guess, font=('Calibri', 40), bg = "pink")
        self.guess_button.pack()

        self.result_label = tk.Label(self.window, text='', font=('Calibri', 24), bg="#9b59b6")
        self.result_label.pack(fill='x')

        self.lives_label = tk.Label(self.window, text=f'Lives: {self.lives}', font=('Calibri', 18), bg="#2ecc71")
        self.lives_label.pack(fill='x')

    def check_guess(self):
        guess = self.guess_entry.get()
        if len(guess) != 1:
            self.result_label['text'] = 'Please enter a single letter.'
            return
        if guess in self.word:
            for i in range(len(self.word)):
                if self.word[i] == guess and self.guessed_letters[i] == '_':
                    self.guessed_letters[i] = guess
                    self.guessed_letters_count += 1
            self.word_label['text'] = ' '.join(self.guessed_letters)
            if self.guessed_letters_count == len(self.word):
                self.result_label['text'] = 'Congratulations, you won!'
                self.guess_button['state'] = 'disabled'
        else:
            self.incorrect_guesses += 1
            self.lives -= 1
            self.result_label['text'] = f'Incorrect guess. {self.lives} chances left.'
            self.lives_label['text'] = f'Lives: {self.lives}'
            if self.lives == 0:
                self.result_label['text'] = f'Game over. The word was {self.word}.'
                self.guess_button['state'] = 'disabled'
        self.guess_entry.delete(0, 'end')

    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    game = Hangman()
    game.run()