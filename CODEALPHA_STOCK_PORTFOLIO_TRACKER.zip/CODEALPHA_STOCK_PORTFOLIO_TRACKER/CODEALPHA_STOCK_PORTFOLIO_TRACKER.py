import yfinance as yf
import tkinter as tk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import time

# Create the main window
root = tk.Tk()
root.title("Stock Portfolio")
root.configure(bg='sky blue')

# Create a frame to hold the stock information
stock_frame = tk.Frame(root)
stock_frame.pack()

# Function to fetch and update stock data
def update_stock_data():
    stocks = ["AAPL", "GOOGL", "AMZN"]  # Replace with your desired stocks
    data = yf.download(stocks, period="1d", interval="1m")

    # Create a figure and plot for real-time visualization
    fig, ax = plt.subplots(figsize=(6, 4))
    fig.set_facecolor('#FFC5C5')  # Add this line
    ax.set_facecolor('#FFD7BE')  # Add this line
    ax.plot(data["Close"])
    ax.set_xlabel("Time")
    ax.set_ylabel("Price")
    ax.set_title("Real-time Stock Prices")

    # Create a canvas to display the plot in the Tkinter window
    canvas = FigureCanvasTkAgg(fig, master=stock_frame)
    canvas.draw()
    canvas.get_tk_widget().pack()

    # Update the plot every minute
    root.after(60000, update_stock_data)

# Call the update function initially
update_stock_data()

# Start the Tkinter event loop
root.mainloop()